//handel nav
if(window.innerWidth<1000){
var menu = document.getElementById('menu');
menu.addEventListener('click', show);
function show(){
	var menu_div = document.getElementById('menu-div');
	var content = document.getElementById('content');
	var header=document.getElementById('header');
    var closee=document.getElementById('close');
	menu_div.style.display='block';
    
        closee.addEventListener('click', hide);
        content.addEventListener('click', hide);
        function hide(){
        	var menu_div = document.getElementById('menu-div');
        	menu_div.style.display='none';
        }

}
}else{
	var menu_div = document.getElementById('menu-div');
	menu_div.style.display='block';	
}



//handel search
var seah = 1;
if(seah=1){
	var search = document.getElementById('search');
	search.addEventListener('click', showinput);
	function showinput(){
    var seah=2;
	var input=document.getElementById('input');
	input.style.display='block';
}
}else if(seah=2){
	var search = document.getElementById('search');
	search.addEventListener('click', hideiinput);
	function hideiinput(){
    var seah=1;
	var input=document.getElementById('input');
	input.style.display='none';
}
}

